// GNB데이터
const gnb_data = [
  {
    txt: "료칸",
    src: "./images/료칸/료칸.jpg",
    link: "/료칸",
  },
  {
    txt: "리아드",
    src: "./images/리아드/리아드.jpg",
    link: "/리아드",
  },
  {
    txt: "북극",
    src: "./images/북극/북극.jpg",
    link: "북극",
  },
  {
    txt: "사막",
    src: "./images/사막/사막.jpg",
    link: "사막",
  },
  {
    txt: "상징적 도시",
    src: "./images/상징적 도시/상징적 도시.jpg",
    link: "상징적도시",
  },
  {
    txt: "섬",
    src: "./images/섬/섬.jpg",
    link: "섬",
  },
  {
    txt: "세상의 꼭대기",
    src: "./images/세상의 꼭대기/세상의 꼭대기.jpg",
    link: "세상의꼭대기",
  },
  {
    txt: "캐슬",
    src: "./images/캐슬/캐슬.jpg",
    link: "캐슬",
  },
  {
    txt: "키클라데스 주택",
    src: "./images/키클라데스 주택/키클라데스 주택.jpg",
    link: "키클라데스주택",
  },
  {
    txt: "한옥",
    src: "./images/한옥/한옥.jpg",
    link: "한옥",
  },
];

export default gnb_data;