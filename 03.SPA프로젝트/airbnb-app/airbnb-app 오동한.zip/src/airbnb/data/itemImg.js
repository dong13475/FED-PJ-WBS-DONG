const item_Img = {
  료칸:[
    "./images/료칸/1/1.jpg",
    "./images/료칸/1/2.jpg",
    "./images/료칸/1/3.jpg",
    "./images/료칸/1/4.jpg",
    "./images/료칸/1/5.jpg",
    "./images/료칸/1/6.jpg",
    "./images/료칸/1/7.jpg",
    "./images/료칸/1/8.jpg",
    "./images/료칸/1/9.jpg",
  ]
}

export default item_Img;